package kr.ac.jeju.kang.service;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class ProductServiceTest {
//	@Autowired
//	private GoodsService goodsService;
//	@Test
//	public void list() {
//		List<Goods> goodsList = goodsService.list();
//		Assert.assertTrue(goodsList.size() > 0);
//		for(Goods goods : goodsList) {
//			if(goods.id == 1) {
//				Assert.assertEquals("abc", goods.getTitle());
//				
//			}
//		}
//	}
}
